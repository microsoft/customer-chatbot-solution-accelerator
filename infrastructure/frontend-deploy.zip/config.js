// Runtime configuration
window.APP_CONFIG = {
  API_BASE_URL: 'https://ecommerce-backend-202509241047.azurewebsites.net',
  ENVIRONMENT: 'production'
};
